#!/bin/bash
echo "Prerequisite installer script"
exit 0